#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 10:55:43 2024

@author: sboyanova
"""
import os
import pandas as pd
from moviepy import VideoFileClip

# Folder path where the videos are located
folder_path = ''  #add path

# Iterate over all files in the folder
for filename in os.listdir(folder_path):
    if filename.endswith(('.mp4', '.avi', '.mov', '.mkv')):  # Check if the file is a video
        file_path = os.path.join(folder_path, filename)
        
        try:
            # Load the video file
            clip = VideoFileClip(file_path)
            
            # Get the duration in seconds
            duration = int(clip.duration)
            
            # Prepare data for the CSV
            video_info = {'Video ID': filename, 'Length (seconds)': duration}
            
            # Convert the data to a DataFrame
            video_df = pd.DataFrame([video_info])
            
            # Create a new CSV file for each video
            output_file = os.path.join(folder_path, f"{filename}_info.csv")
            video_df.to_csv(output_file, index=False)
            
            # Close the clip to release resources
            clip.close()
            
            print(f"Processed {filename} and saved info to {output_file}")
        except Exception as e:
            print(f"Failed to process {file_path}: {e}")


