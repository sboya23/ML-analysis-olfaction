#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 17:03:55 2024

@author: sboyanova
"""

import os
import csv

# Define folder paths
folder1_path = '' #folder with processed behavioural status file
folder2_path = '' #folder with DLC file
output_folder = os.path.join(folder1_path, 'filtered_files')

# Create output directory if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Helper function to write modified data to a new CSV file
def write_csv(filepath, data):
    with open(filepath, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Iterate over all files in Folder 1
for filename in os.listdir(folder1_path):
    if filename.endswith('.csv'):
        file1_path = os.path.join(folder1_path, filename)
        file2_path = os.path.join(folder2_path, filename)
        output_file_path = os.path.join(output_folder, filename)
        
        # Ensure the corresponding file exists in Folder 2
        if os.path.exists(file2_path):
            # Read contents of the file from Folder 1
            with open(file1_path, 'r', newline='') as file1:
                file1_data = list(csv.reader(file1))
            
            # Read contents of the file from Folder 2
            with open(file2_path, 'r', newline='') as file2:
                file2_data = list(csv.reader(file2))

            # Prepare the modified data for Folder 1 by removing matching rows based on Folder 2's column 33
            modified_file1_data = []
            
            # Create a dictionary to map values in Folder 2's column 0 to their row indexes
            folder2_row_map = {int(row[0]): row for row in file2_data if row[0].isdigit()}

            # Iterate through rows in Folder 1 starting from index 1
            for row_index in range(1, len(file1_data)):
                # Match the row in Folder 1 to the row in Folder 2 where column 0 has a value equal to (row_index - 1)
                matching_value = row_index - 1

                # Check if the corresponding row exists in Folder 2
                if matching_value in folder2_row_map:
                    matching_row2 = folder2_row_map[matching_value]

                    # Check the value of column index 33 in Folder 2's matching row
                    if float(matching_row2[33]) >= 0.8:
                        # If the value is >= 0.8, keep the row from Folder 1
                        modified_file1_data.append(file1_data[row_index])
                else:
                    # If no matching row is found in Folder 2, keep the row from Folder 1
                    modified_file1_data.append(file1_data[row_index])

            # Add the header row from Folder 1 if it exists (assuming index 0 is the header)
            if len(file1_data) > 0:
                modified_file1_data.insert(0, file1_data[0])

            # Write the modified data to a new CSV file in the output folder
            write_csv(output_file_path, modified_file1_data)

print(f"Processing completed. Filtered files are saved in {output_folder}")
