#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 17:16:13 2024

@author: sboyanova
"""

import csv
import os

# Define the folder path containing the CSV files
folder_path = '' _final/filtered_files folder path
output_folder = os.path.join(folder_path, 'modified_files')

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Helper function to write modified data to a new CSV file
def write_csv(filepath, data):
    with open(filepath, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Iterate over all files in the folder
for filename in os.listdir(folder_path):
    if filename.endswith('.csv'):
        file_path = os.path.join(folder_path, filename)
        output_file_path = os.path.join(output_folder, filename)

        # Read the CSV file
        with open(file_path, 'r', newline='') as file:
            data = list(csv.reader(file))

        # Start modifying the first column from index 1 (leave the header intact if present)
        increment_value = 0.0
        for i in range(1, len(data)):
            # Stop modifying if the second column is empty or missing
            if not data[i][1].strip():  # Checks if the second column is empty or has only spaces
                break
            # Update the first column with the incrementing values
            data[i][0] = f'{increment_value:.2f}'
            increment_value += 0.04

        # Write the modified data to a new CSV file in the output folder
        write_csv(output_file_path, data)

print(f"Processing completed. Modified files are saved in {output_folder}")



